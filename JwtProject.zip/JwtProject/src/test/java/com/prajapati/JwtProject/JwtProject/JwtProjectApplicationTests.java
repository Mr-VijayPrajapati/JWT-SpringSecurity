package com.prajapati.JwtProject.JwtProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
