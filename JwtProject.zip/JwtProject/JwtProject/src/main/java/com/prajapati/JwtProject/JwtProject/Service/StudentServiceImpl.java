package com.prajapati.JwtProject.JwtProject.Service;

import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;

import com.prajapati.JwtProject.JwtProject.DTO.StudentDTO;
import com.prajapati.JwtProject.JwtProject.Entity.Student;
import com.prajapati.JwtProject.JwtProject.Repository.StudentRepository;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService{
      private final StudentRepository studentRepository;

      private StudentDTO mapToDTO(Student student){
        return new StudentDTO(student.getId(),student.getName(),student.getFathername(),student.getStudentclass());
      } 

      private Student  mapToEntity(StudentDTO dto){
        Student s=new Student();
        s.setId(dto.getId());
        s.setName(dto.getName());
        s.setFathername(dto.getFathername());
        s.setStudentclass(dto.getStudentclass());
        return s;
      }

  @Override
public StudentDTO registerStudent(StudentDTO dto) {
    Student saved = studentRepository.save(mapToEntity(dto));
    return mapToDTO(saved);
}


 @Override
public StudentDTO findById(Long id) {
    Student student = studentRepository.findById(id)
            .orElseThrow(() -> new NoSuchElementException("Student not found with id: " + id));
    return mapToDTO(student);
}

}