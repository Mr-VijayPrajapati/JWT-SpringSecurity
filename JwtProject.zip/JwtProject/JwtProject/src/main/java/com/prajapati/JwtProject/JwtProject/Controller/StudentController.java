package com.prajapati.JwtProject.JwtProject.Controller;

import org.springframework.web.bind.annotation.*;
import com.prajapati.JwtProject.JwtProject.DTO.StudentDTO;
import com.prajapati.JwtProject.JwtProject.Service.StudentService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/student")
public class StudentController {

    private final StudentService studentService;




    // Get student by ID
    @GetMapping("/{id}")
    public StudentDTO getById(@PathVariable Long id) {
        return studentService.findById(id);
    }

    // Register a new student
    @PostMapping("/new-admission")
    public StudentDTO createStudent(@RequestBody StudentDTO studentDTO) {
        return studentService.registerStudent(studentDTO);
    }
}
