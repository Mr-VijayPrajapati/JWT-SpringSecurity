package com.prajapati.JwtProject.JwtProject.Service;

import com.prajapati.JwtProject.JwtProject.DTO.StudentDTO;
import com.prajapati.JwtProject.JwtProject.Entity.Student;

public interface StudentService {
    StudentDTO registerStudent(StudentDTO dto);
    StudentDTO findById(Long id);
}
