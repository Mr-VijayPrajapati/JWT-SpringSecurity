package com.prajapati.JwtProject.JwtProject.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {

    private Long id;

    @NotBlank(message = "Username cannot be blank")
    @Size(min = 5, max = 25, message = "Username must be 5-25 characters long")
    private String username;

    @NotBlank(message = "Password cannot be blank")
    @Size(min = 7, max = 50, message = "Password must be 7-50 characters long")
    @Pattern(
        regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&*]).{7,50}$",
        message = "Password must contain at least one digit, one lowercase, one uppercase, one special character (@#$%&*)"
    )
    private String password;
}
