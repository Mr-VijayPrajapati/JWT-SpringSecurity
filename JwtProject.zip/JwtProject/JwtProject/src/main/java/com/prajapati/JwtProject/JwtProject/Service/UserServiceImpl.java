package com.prajapati.JwtProject.JwtProject.Service;

import com.prajapati.JwtProject.JwtProject.DTO.UserDTO;
import com.prajapati.JwtProject.JwtProject.Entity.User;
import com.prajapati.JwtProject.JwtProject.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public UserDTO signup(UserDTO userDTO) {
        User user = new User();
        user.setUsername(userDTO.getUsername());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));

        User savedUser = userRepository.save(user);

        userDTO.setId(savedUser.getId());
        userDTO.setPassword(null); // clear password
        return userDTO;
    }

    @Override
    public boolean login(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        return userOpt.map(user -> passwordEncoder.matches(password, user.getPassword()))
                      .orElse(false);
    }
}
