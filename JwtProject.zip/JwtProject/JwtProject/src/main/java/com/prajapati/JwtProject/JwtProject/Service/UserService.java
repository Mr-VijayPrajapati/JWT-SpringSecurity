package com.prajapati.JwtProject.JwtProject.Service;

import com.prajapati.JwtProject.JwtProject.DTO.UserDTO;

public interface UserService {
    UserDTO signup(UserDTO userDTO);
    boolean login(String username, String password);
}
