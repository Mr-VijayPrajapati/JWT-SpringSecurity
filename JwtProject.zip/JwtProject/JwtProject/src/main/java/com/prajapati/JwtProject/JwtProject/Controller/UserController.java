package com.prajapati.JwtProject.JwtProject.Controller;

import com.prajapati.JwtProject.JwtProject.DTO.UserDTO;
import com.prajapati.JwtProject.JwtProject.Response.ApiResponse;
import com.prajapati.JwtProject.JwtProject.Service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService; // fixed interface name

    // Signup
    @PostMapping("/signup")
    public ApiResponse<UserDTO> signup(@RequestBody UserDTO userDTO) {
        UserDTO createdUser = userService.signup(userDTO); // fixed method name
        return new ApiResponse<>(true, "User registered successfully", createdUser);
    }

    // Login
    @PostMapping("/login")
    public ApiResponse<Void> login(@RequestBody UserDTO userDTO) {
        boolean success = userService.login(userDTO.getUsername(), userDTO.getPassword());
        if (success) {
            return new ApiResponse<>(true, "Login successful", null);
        } else {
            return new ApiResponse<>(false, "Invalid credentials", null);
        }
    }
}
